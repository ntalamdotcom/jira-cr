export declare const fetchJiraProjects: () => Promise<JiraProject[]>;
export declare const fetchJiraIssues: () => Promise<JiraIssues[]>;
