export default function ProjectsDataTable(params: {
    data: JiraProject[] | undefined;
}): import("react").JSX.Element;
